#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 Parser module
-- Name: plarse
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.1
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
plarse = {}			-- 模块名
local _M = plarse	-- 临时模块名
dofile('plenv.lua')	-- 引入模块
require 'plex'
require 'plame'
require 'plerr'

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
local layer = 0
local address = 0
local 	parseProgram, parseSubProgram, parseDeclareConst, parseDefineConst, parseDeclareVar, parseDeclareProcedure, parseProcedureHead, 
		parseStatemant, parseStatemantCompoud, parseStatemantAssign, parseStatemantIf, parseStatemantWhile, parseStatemantRepeat, parseStatemantCall, parseStatemantRead, parseStatemantWrite, 
		parseCondition, parseAddSubOperator, parseMulDivOperator, parseExpression, parseTerm, parseFactor, parseIdentifier, parseNumber, parseString

-- Tools
local function testToken(type)		-- test only
	return Token.type==TokenType[type]
end
local function absorbToken(type)	-- test, if match then get next token
	if Token.type==TokenType[type] then
		plex.nextToken()
		return true
	else
		return false
	end
end
local function err(id)
	plerr.what('Plarse',id)
end

-- Local Debug
local function dbg(func)
	print('[Func] '..func..'\t\t[Token] '..(Token.type or '<NK>')..'\t'..(Token.value or '<Symbol>'))
end

-- Parsers
function parseProgram()			-- ﻿<程序> ::= <分程序>.
	dbg('Program')
	if parseSubProgram() then
		if absorbToken('PERIOD') then
			return true
		else
			err(301)
			return false
		end
	end
end
function parseSubProgram()		-- <分程序> ::= [<常量说明部分>][变量说明部分>][<过程说明部分>]<语句>
	dbg('SubProgram')
	while testToken('CONST') or testToken('VAR') or testToken('PROCEDURE') do
		if testToken('CONST') then parseDeclareConst() end
		if testToken('VAR') then parseDeclareVar() end
		if testToken('PROCEDURE') then parseDeclareProcedure() end
	end
	return parseStatemant()
end
function parseDeclareConst()		-- <常量说明部分> ::= const<常量定义>{,<常量定义>};
	dbg('DeclareConst')
	if absorbToken('CONST') then
		if testToken('ID') then
			parseDefineConst()
			while absorbToken('COMMA') do
				if not parseDefineConst() then
					return false
				end
			end
			if absorbToken('SEMICOLON') then
				return true
			else
				err(302)
				return false
			end
		else
			err(313)
			return false
		end
	else
		err(300)
		return false
	end
end
function parseDefineConst()		-- <常量定义> ::= <标识符>=<无符号整数>
	dbg('DefineConst')
	if testToken('ID') then
		_id=parseIdentifier()
		if plame.getName(_id) then
			err(402)
			return false
		else
			plame.setName(_id,'CONST')
		end
		if absorbToken('EQU') then
			_num=parseNumber()
			plame.setValue(_id,_num)
			return true
		else
			err(303)
			return false
		end
	else
		err(313)
		return false
	end
end
function parseDeclareVar()		-- <变量说明部分>::= var<标识符>{,<标识符>};
	dbg('DeclareVar')
	if absorbToken('VAR') then
		if testToken('ID') then
			_id=parseIdentifier()
			if plame.getName(_id) then
				err(402)
				return false
			else
				plame.setName(_id,'VAR')
				while absorbToken('COMMA') do
					if testToken('ID') then
						_id=parseIdentifier()
						if plame.getName(_id) then
							err(402)
							return false
						else
							plame.setName(_id,'VAR')
						end
					else
						err(313)
						return false
					end
				end
				if absorbToken('SEMICOLON') then
					return true
				else
					err(302)
					return false
				end
			end
		else
			err(313)
			return false
		end
	else
		err(300)
		return false
	end
end
function parseDeclareProcedure()	-- <过程说明部分> ::= <过程首部><分程序>;{<过程说明部分>} -- Modified
	dbg('DeclareProcedure')
	if parseProcedureHead() then
		if parseSubProgram() then
			if absorbToken('SEMICOLON') then
				while absorbToken('PROCEDURE') do
					if not parseDeclareProcedure() then
						return false
					end
				end
				return true
			else
				err(302)
				return false
			end
		else
			return false
		end
	else
		return false
	end
end
function parseProcedureHead()		-- <过程首部> ::= procedure<标识符>;
	dbg('ProcedureHead')
	if absorbToken('PROCEDURE') then
		if testToken('ID') then
			_id=parseIdentifier()
			if plame.getName(_id) then
				err(402)
				return false
			else
				plame.setName(_id,'PROCEDURE')
				if absorbToken('SEMICOLON') then
					return true
				else
					err(302)
					return false
				end
			end
		else
			err(313)
			return false
		end
	else
		err(300)
		return false
	end
end
function parseStatemant()			-- <语句> ::= <赋值语句>|<条件语句>|<当型循环语句>|<过程调用语句>|<读语句>|<写语句>|<复合语句>|<重复语句>|<空>
	dbg('Statemant')
	if testToken('BEGIN') then return parseStatemantCompoud()
	elseif testToken('ID') then return parseStatemantAssign()
	elseif testToken('IF') then return parseStatemantIf()
	elseif testToken('WHILE') then return parseStatemantWhile()
	elseif testToken('DO') then return parseStatemantWhile()
	elseif testToken('REPEAT') then return parseStatemantRepeat()
	elseif testToken('CALL') then return parseStatemantCall()
	elseif testToken('READ') then return parseStatemantRead()
	elseif testToken('WRITE') then return parseStatemantWrite()
	elseif absorbToken('SEMICOLON') then return true	-- Null Statement
	else return false end
end
function parseStatemantCompoud()	-- <复合语句> ::= begin<语句>{;<语句>}end
	dbg('StatemantCompoud')
	if absorbToken('BEGIN') then
		if absorbToken('END') then return true end	-- Support Nil Statement
		if parseStatemant() then
			while absorbToken('SEMICOLON') do
				if absorbToken('END') then
					return true
				elseif not parseStatemant() then
					return false
				end
			end
			if absorbToken('END') then
				return true
			else
				err(304)
				return false
			end
		else
			err(312)
			return false
		end
	else
		err(300)
		return false
	end
end
function parseStatemantAssign()	-- <赋值语句> ::= <标识符>:=<表达式>
	dbg('StatemantAssign')
	if testToken('ID') then
		_id=parseIdentifier()
		if not plame.getName(_id) then
			err(401)
			return false
		elseif not plame.isAssignable(_id) then
			err(403)
			return false
		else
			if absorbToken('ASSIGN') then
				parseExpression()
				-- TODO: What to do
				-- TODO
				-- TODO
				return true
			else
				err(305)
				return false
			end
		end
	else
		err(313)
		return false
	end
end
function parseStatemantIf()		-- <条件语句> ::= if<条件>then<语句>[else<语句>]
	dbg('StatemantIf')
	if absorbToken('IF') then
		if parseCondition() then
			if absorbToken('THEN') then
				if parseStatemant() then
					if absorbToken('ELSE') then
						if parseStatemant() then
							-- TODO
							-- TODO
							-- TODO
							return true
						end
					end
					return true
				else
					err(312)
					return false
				end
			else
				err(306)
				return false
			end
		else
			return false
		end
	else
		err(300)
		return false
	end
end
function parseStatemantWhile()	-- <当型循环语句> ::= while<条件>do<语句>|do<语句>while<条件>
	dbg('StatemantWhile')
	if absorbToken('WHILE') then
		if parseCondition() then
			if absorbToken('DO') then
				if parseStatemant() then
					-- TODO
					-- TODO
					-- TODO
					return true
				end
			else
				err(307)
				return false
			end
		else
			return false
		end
	elseif absorbToken('DO') then
		if parseStatemant() then
			if absorbToken('WHILE') then
				if parseCondition() then
					-- TODO
					-- TODO
					-- TODO
					return true
				end
			else
				err(308)
				return false
			end
		else
			err(312)
			return false
		end
	else
		err(300)
		return false
	end
end
function parseStatemantRepeat()	-- <重复语句> ::= repeat<语句>{;<语句>}until<条件>
	dbg('StatemantRepeat')
	if absorbToken('REPEAT') then
		if parseStatemant() then
			while absorbToken('SEMICOLON') do
				if not parseStatemant() then
					return false
				end
			end
			if absorbToken('UNTIL') then
				if parseCondition() then
					-- TODO
					-- TODO
					-- TODO
					return true
				end
			else
				err(309)
				return false
			end
		else
			err(312)
			return false
		end
	else
		err(300)
		return false
	end
end
function parseStatemantCall()		-- <过程调用语句> ::= call<标识符>
	dbg('StatemantCall')
	if absorbToken('CALL') then
		if testToken('ID') then
			_id=parseIdentifier()
			if not plame.getName(_id) then
				err(401)
				return false
			elseif not plame.isCallable(_id) then
				err(404)
				return false
			else
				-- TODO
				-- TODO
				-- TODO
				return true
			end
		else
			err(313)
			return false
		end
	else
		err(300)
		return false
	end
end
function parseStatemantRead()		-- <读语句> ::= read'('<标识符>{,<标识符>}')‘
	dbg('StatemantRead')
	if absorbToken('READ') then
		if absorbToken('LRDBR') then
			if testToken('ID') then
				_id=parseIdentifier()
				if not plame.getName(_id) then
					err(401)
					return false
				else
					while absorbToken('COMMA') do
						if testToken('ID') then
							_id=parseIdentifier()
							if not plame.getName(_id) then
								err(401)
								return false
							end
						else
							err(313)
							return false
						end
					end
					if absorbToken('RRDBR') then
						-- TODO
						-- TODO
						-- TODO
						return true
					else
						err(311)
						return false
					end
				end
			else
				err(313)
				return false
			end
		else
			err(310)
			return false
		end
	else
		err(300)
		return false
	end
end
function parseStatemantWrite()	-- <写语句> ::= write'('<标识符>{,<标识符>}')‘
	dbg('StatemantWrite')
	if absorbToken('WRITE') then
		if absorbToken('LRDBR') then
			if testToken('ID') then
				_id=parseIdentifier()
				if not plame.getName(_id) then
					err(401)
					return false
				else
					while absorbToken('COMMA') do
						if testToken('ID') then
							_id=parseIdentifier()
							if not plame.getName(_id) then
								err(401)
								return false
							end
						else
							err(313)
							return false
						end
					end
					if absorbToken('RRDBR') then
						-- TODO
						-- TODO
						-- TODO
						return true
					else
						err(311)
						return false
					end
				end
			else
				err(313)
				return false
			end
		else
			err(310)
			return false
		end
	else
		err(300)
		return false
	end
end
function parseCondition()			-- <条件> ::= <表达式><关系运算符><表达式>|odd<表达式>
	dbg('Condition')
	if absorbToken('ODD') then
		if 	parseExpression() then
			-- TODO
			-- TODO
			-- TODO
			return true
		else
			return false
		end
	else
		if parseExpression() then
			local _rel = 1
			if absorbToken('EQU') then
				_rel='='
			elseif absorbToken('NEQ') then
				_rel='<>'
			elseif absorbToken('LES') then
				_rel='<'
			elseif absorbToken('ELT') then
				_rel='<='
			elseif absorbToken('GRT') then
				_rel='>'
			elseif absorbToken('EGT') then
				_rel='>='
			else
				err(314)
				return false
			end
			if parseExpression() then
				-- TODO
				-- TODO
				-- TODO
				return true
			else
				err(315)
				return false
			end
		else
			err(315)
			return false
		end
	end
end
function parseExpression()		-- <表达式> ::= [+|-]<项>{<加法运算符><项>}
	dbg('Expression')
	local _sign = 0		-- pos=0,neg=1
	if absorbToken('ADD') then
		_sign=0
	elseif absorbToken('SUB') then
		_sign=1
	end
	if parseTerm() then
		local _op
		while testToken('ADD') or testToken('SUB') do
			if absorbToken('ADD') then
				_op='+'
			elseif absorbToken('SUB') then
				_op='-'
			end
			parseTerm()
		end
		return true
	else
		return false
	end
end
function parseTerm()				-- <项> ::= <因子>{<乘法运算符><因子>}
	dbg('Term')
	if parseFactor() then
		local _op
		while  testToken('MUL') or testToken('DIV')  do
			if absorbToken('MUL') then
				_op='*'
			elseif absorbToken('DIV') then
				_op='/'
			end
			parseFactor()
		end
		return true
	else
		return false
	end
end
function parseFactor()			-- <因子> ::= <标识符>|<数>|'('<表达式>')‘
	dbg('Factor')
	if testToken('ID') then
		return parseIdentifier()
	elseif testToken('NUM') then
		return parseNumber()
	elseif absorbToken('LRDBR') then
		if parseExpression() then
			if absorbToken('RRDBR') then
				return true
			else
				err(311)
				return false
			end
		else
			err(315)
			return false
		end
	else
		return false
	end
end
function parseIdentifier()		-- <标识符> ::= <字母>{<字母>|{<数字>}}
	dbg('Identifier')
	if testToken('ID') then
		t=Token.value
		plex.nextToken()	-- absorb for debug
		return t
	else
		return false
	end
end
function parseNumber()			-- <数> ::= <数字>{<数字>}.{<数字>}
	dbg('Number')
	if testToken('NUM') then
		t=Token.value
		plex.nextToken()	-- absorb for debug
		return t
	else
		return false
	end
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
function _M.init(fin)
	plex.init(fin)
	plame.init()
end
function _M.startParse()
	plex.nextToken()		-- Pre-read a token
	if not parseProgram() then
		print('#233: Your program is poisonous..')
	else
		print('#666: Parsing finished, no big problem currently...')
	end
	plame.test()
end

-----------------------------------------------------------------------------
-- Debug functions
-----------------------------------------------------------------------------
function _M.test(fin)
	_M.init(fin)
	_M.startParse()
end

-----------------------------------------------------------------------------
return _M
