#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 P-Code Generator module
-- Name: plode
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.0
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
plode = {}				-- 模块名
local _M = plode		-- 临时模块名
dofile('plenv.lua')		-- 执行全局参数设定
require 'plerr'

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
-- Tools
local function err(id)
	plerr.what('Plerr',id)
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
function _M.init(fout)
	FileOut = io.open(fout, "w")
	Cur_Count = 0
	if not FileOut then
		err(102)
		return false
	end
	return true
end
function _M.write(pcmd,layerdiff,x)
	FileOut:write(pcmd..' '..layerdiff..', '..x)
	Cur_Count=Cur_Count+1
end

-----------------------------------------------------------------------------
-- Debug functions
-----------------------------------------------------------------------------
function _M.status()
	print("PCoder Status:")
	print("Line\t=\t"..Cur_Line)
	print("Token\t=\t"..Token.type.."\t"..Token.value)
	print()
end
function _M.test(fout)
	_M.init(fout)
	_M.write(PCode.WRT,0,0)
end

-----------------------------------------------------------------------------
return _M
