#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 Symbol-Name Table module
-- Name: plame
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.0
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
plame = {}			-- 模块名
local _M = plame		-- 临时模块名
dofile('plenv.lua')	-- 执行全局参数设定

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
local function existName(name)
	return Namespace[tostring(name)]
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
function _M.init()
	Namespace={}
end
function _M.getName(name)
	return Namespace[tostring(name)]
end
function _M.setName(name,_type)			-- _type='VAR'|'CONST'|'PROCEDURE'
	if existName(name) then
		return false
	else
		Namespace[tostring(name)]={}
		Namespace[tostring(name)].type=_type
		return true
	end
end
function _M.setValue(name,_value)
	if not existName(name) then
		return false
	else
		Namespace[tostring(name)].value=_value
		return true
	end
end
function _M.setLayer(name,_layer)
	if not existName(name) then
		return false
	else
		Namespace[tostring(name)].layer=_layer
		return true
	end
end
function _M.setAddress(name,_address)
	if not existName(name) then
		return false
	else
		Namespace[tostring(name)].address=_address
		return true
	end
end
function _M.isAssignable(name)
	return Namespace[tostring(name)] or Namespace[tostring(name)].type=='VAR'
end
function _M.isCallable(name)
	return Namespace[tostring(name)] or Namespace[tostring(name)].type=='PROCEDURE'
end

-----------------------------------------------------------------------------
-- Debug functions
-----------------------------------------------------------------------------
function _M.test()
	print('Namespace Table:')
	print('================')
	local _cnt = 1
	for k,v in pairs(Namespace) do
		print('#'.._cnt..': '..k)
		for sk,sv in pairs(v) do
			print('\t<'..sk..'>:\t'..sv)
		end
		_cnt=_cnt+1
	end
	print()
end

-----------------------------------------------------------------------------
return _M
