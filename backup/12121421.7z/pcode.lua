#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 P-Code Generator module
-- Name: pcode
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.0
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
pcode = {}				-- 模块名
local _M = pcode		-- 临时模块名
dofile('common.lua')	-- 执行全局参数设定

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
-- Tools
local function err(id,msg)
	if id == 0 then				-- Fatal Error
		print('<<PCode Fatal Error>>: '..msg)
		os.exit()
	else
		print('[PCoding Error]: #'..Cur_Line..':'..Cur_Column..' => '..msg)
	end
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
function _M.init(fout)
	FileOut = io.open(fout, "w")
	Cur_Count = 0
	if not FileOut then
		err(0,"Destination file cannot open")
		return false
	end
	return true
end
function _M.write(pcmd,layerdiff,x)
	FileOut:write(tostring(pcmd)..' '..tostring(layerdiff)..', '..tostring(x))
	Cur_Count=Cur_Count+1
end

-----------------------------------------------------------------------------
-- Debug functions
-----------------------------------------------------------------------------
function _M.status()
	print("PCoder Status:")
	print("Line\t=\t"..tostring(Cur_Line))
	print("Token\t=\t"..tostring(Token.type).."\t"..tostring(Token.val))
	print()
end
function _M.test(fout)
	_M.init(fout)
	_M.write(PCode.WRT,0,0)
end

-----------------------------------------------------------------------------
return _M
