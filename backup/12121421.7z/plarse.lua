#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 Parser module
-- Name: plarse
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.1
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
plarse = {}			-- 模块名
local _M = plarse	-- 临时模块名
require 'plcommon'	-- 引入模块
require 'plex'
require 'plerr'

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
local layer = 0
local address = 0

-- Parsers
local function parseProgram()			-- ﻿<程序> ::= <分程序>.
	parseSubProgram()
	if checkToken('PERIOD') then
		nextToken()
		return true
	else
		err(301)
		return false
	end
	err(111)
end
local function parseSubProgram()		-- <分程序> ::= [<常量说明部分>][变量说明部分>][<过程说明部分>]<语句>
	if checkToken('CONST') then parseDeclareConst()	end
	if checkToken('VAR') then parseDeclareVar()	end
	if checkToken('PROCEDURE') then parseDeclareProcedure() end
	return parseStatemant()
	-- err(312)
end
local function parseDeclareConst()		-- <常量说明部分> ::= const<常量定义>{,<常量定义>};
	if checkToken('CONST') then
		nextToken()
		if parseDefineConst() then
			while true do
				if checkToken('COMMA') then
					nextToken()
					parseDefineConst()
				else
					err(305)
					return false
				end
			end
		else
			err(352)
			return false
		end
		if checkToken('SEMICOLON') then
			plex.nextToken()
			return true
		else
			err(304)
			return false
		end
	else
		print('Missing CONST...error call?')
		return false
	end
	err(113)
end
local function parseDefineConst()		-- <常量定义> ::= <标识符>=<无符号整数>
	if checkToken('ID') then
		-- TODO: deal with id
		parseIdentifier()
		nextToken()
		if checkToken('EQU') then
			nextToken()
			-- TODO: deal with num
			parseNumber()
		else
			err(303)
			return false
		end
	else
		print('Missing ID...error call?')
		return false
	end
	err(114)
end
local function parseDeclareVar()		-- <变量说明部分>::= var<标识符>{,<标识符>};
	if checkToken('VAR') then
		nextToken()
		-- TODO: deal with id
		parseIdentifier()
		while true do
			if checkToken('COMMA') then
				nextToken()
				-- TODO: deal with id
				parseIdentifier()
			else
				break
			end
		end
		if checkToken('SEMICOLON') then
			nextToken()
			return true
		else
			err(304)
			return false
		end
	else
		print('Missing VAR...error call?')
		return false
	end
	err(115)
end
local function parseDeclareProcedure()	-- <过程说明部分> ::= <过程首部><分程序>;{<过程说明部分>} -- Modified
	parseProcedureHead()
	parseSubProgram()
	if checkToken('SEMICOLON') then
		nextToken()
	else
		err(304)
		return false
	end
	while true do
		if checkToken('PROCEDURE') then
			nextToken()
			parseDeclareProcedure()
		else
			return true
		end
	end
	err(116)
end
local function parseProcedureHead()		-- <过程首部> ::= procedure<标识符>;
	if checkToken('PROCEDURE') then
		nextToken()
		parseIdentifier()
		if checkToken('SEMICOLON') then
			nextToken()
			return true
		else
			err(304)
			return false
		end
	else
		print('Missing PROCEDURE...error call?')
		return false
	end
	err(117)
end
local function parseStatemant()			-- <语句> ::= <赋值语句>|<条件语句>|<当型循环语句>|<过程调用语句>|<读语句>|<写语句>|<复合语句>|<重复语句>|<空>
	if checkToken('BEGIN') then return parseStatemantCompoud()
	elseif checkToken('ID') then return parseStatemantAssign()
	elseif checkToken('IF') then return parseStatemantIf()
	elseif checkToken('WHILE') then return parseStatemantWhile()
	elseif checkToken('REPEAT') then return parseStatemantRepeat()
	elseif checkToken('CALL') then return parseStatemantCall()
	elseif checkToken('READ') then return parseStatemantRead()
	elseif checkToken('WRITE') then return parseStatemantWrite()
	elseif checkToken('SEMICOLON') then
		nextToken()
		return true		-- Null Statement
	else
		print('Missing PROCEDURE...error call?')
		return false
	end
	err(118)
end
local function parseStatemantCompoud()	-- <复合语句> ::= begin<语句>{;<语句>}end
	if checkToken('BEGIN') then
		nextToken()
		parseStatemant()
		while checkToken('SEMICOLON') do
			nextToken()
			parseStatemant()
		end
		if checkToken('END') then
			nextToken()
			return true
		else
			err(374)
			return false
		end
	else
		print('Missing BEGIN...error call?')
		return false
	end
	err(119)
end
local function parseStatemantAssign()	-- <赋值语句> ::= <标识符>:=<表达式>
	parseStatemant()
	if checkToken('EQU') then
		nextToken()
		return true
	else
		err(303)
		return false
	end
	parseExpression()
	return true
	--err(120)
end
local function parseStatemantIf()		-- <条件语句> ::= if<条件>then<语句>[else<语句>]
	if checkToken('IF') then
		nextToken()
		parseCondition()
		if checkToken('THEN') then
			nextToken()
			parseStatemant()
			if checkToken('ELSE') then
				nextToken()
				parseStatemant()
			else
				err(377)
				return false
			end
			return true
		else
			err(373)
			return false
		end
	else
		print('Missing IF...error call?')
		return false
	end
	err(121)
end
local function parseStatemantWhile()	-- <当型循环语句> ::= while<条件>do<语句>
	if checkToken('WHILE') then
		nextToken()
		parseCondition()
		if checkToken('DO') then
			nextToken()
			parseStatemant()
			return true
		else
			err(372)
			return false
		end
	else
		print('Missing WHILE...error call?')
		return false
	end
	err(122)
end
local function parseStatemantRepeat()	-- <重复语句> ::= repeat<语句>{;<语句>}until<条件>
	if checkToken('REPEAT') then
		nextToken()
		parseStatemant()
		while checkToken('SEMICOLON') do
			nextToken()
			parseStatemant()
		end
		if checkToken('UNTIL') then
			nextToken()
			parseCondition()
			return true
		else
			err(379)
			return false
		end
	else
		print('Missing REPEAT...error call?')
		return false
	end
	err(123)
end
local function parseStatemantCall()		-- <过程调用语句> ::= call<标识符>
	if checkToken('CALL') then
		nextToken()
		parseIdentifier()
		return true
	else
		print('Missing CALL...error call?')
		return false
	end
	err(124)
end
local function parseStatemantRead()		-- <读语句> ::= read'('<标识符>{,<标识符>}')‘
	if checkToken('READ') then
		nextToken()
		if checkToken('LRDBR') then
			nextToken()
			parseIdentifier()
			while checkToken('COMMA') do
				nextToken()
				parseIdentifier()
			end
			if checkToken('RRDBR') then
				nextToken()
				return true
			else
				err(302)
				return false
			end
		else
			err(380)
			return false
		end
	else
		print('Missing READ...error call?')
		return false
	end
	err(125)
end
local function parseStatemantWrite()	-- <写语句> ::= write'('<标识符>{,<标识符>}')‘
	if checkToken('WRITE') then
		nextToken()
		if checkToken('LRDBR') then
			nextToken()
			parseIdentifier()
			while checkToken('COMMA') do
				nextToken()
				parseIdentifier()
			end
			if checkToken('RRDBR') then
				nextToken()
				return true
			else
				err(302)
				return false
			end
		else
			err(380)
			return false
		end
	else
		print('Mising WRITE...error call?')
		return false
	end
	err(126)
end
local function parseCondition()			-- <条件> ::= <表达式><关系运算符><表达式>|odd<表达式>
	if checkToken('ODD') then
		nextToken()
		parseExpression()
		return true
	else
		parseExpression()
		parseRelationOperator()
		parseExpression()
		return true
	end
	err(127)
end
local function parseAddSubOperator()	-- <加法运算符> ::= +|-
	if checkToken('ADD') then
		nextToken()
		return true
	elseif checkToken('SUB') then
		nextToken()
		return true
	else
		print('Missing AddSubOperator...error call?')
		return false
	end
	err(128)
end
local function parseMulDivOperator()	-- <乘法运算符> ::= *|/|%
	if checkToken('MUL') then
		nextToken()
		return true
	elseif checkToken('DIV') then
		nextToken()
		return true
	elseif checkToken('MOD') then
		nextToken()
		return true
	else
		print('Missing MulDivOperator...error call?')
		return false
	end
	err(129)
end
local function parseRelationOperator()	-- <关系运算符> ::= =|<>|<|<=|>|>=
	if checkToken('EQU') then
		nextToken()
		return true
	elseif checkToken('NEQ') then
		nextToken()
		return true
	elseif checkToken('LES') then
		nextToken()
		return true
	elseif checkToken('ELT') then
		nextToken()
		return true
	elseif checkToken('GRT') then
		nextToken()
		return true
	elseif checkToken('EGT') then
		nextToken()
		return true
	else
		print('Missing RelationOperator...error call?')
		return false
	end
	err(130)
end
local function parseExpression()		-- <表达式> ::= [+|-]<项>{<加法运算符><项>}
	local _sign = 0		-- pos=0,neg=1
	if checkToken('ADD') then
		nextToken()
		_sign=1
	elseif checkToken('SUB') then
		nextToken()
		_sign=0
	end
	parseTerm()
	while parseAddSubOperator() do
		parseTerm()
	end
	err(131)
end
local function parseTerm()				-- <项> ::= <因子>{<乘法运算符><因子>}
	parseFactor()
	while parseMulDivOperator() do
		parseFactor()
	end
	err(132)
end
local function parseFactor()			-- <因子> ::= <标识符>|<无符号整数>|'('<表达式>')‘
	if checkToken('ID') then parseIdentifier()
	elseif checkToken('NUM') then parseNumber()
	elseif checkToken('LRDBR') then
		parseExpression()
		if checkToken('RRDBR') then
			nextToken()
			return true
		else
			err(302)
			return false
		end
	end
	err(133)
end
local function parseIdentifier()		-- <标识符> ::= <字母>{<字母>|<数字>}
	if checkToken('ID') then
		-- TODO: save to symtab
		nextToken()
		return true
	else
		print('Mising ID...error call?')
		return false
	end
	err(134)
end
local function parseNumber()			-- <无符号整数> ::= <数字>{<数字>}
	if checkToken('NUM') then
		-- TODO returnval?
		nextToken()
		return true
	else
		print('Mising NUM...error call?')
		return false
	end
	err(135)
end

-- Tools
local function nextToken()
	plex.nextToken()
end
local function checkToken(type)
	return Token.type==TokenType[type]
end
local function testToken_preview(type)
	return Token.type==TokenType[type]
end
local function absorbToken_preview(type)
	if Token.type==TokenType[type] then
		plex.nextToken()
		return true
	else
		return false
	end
end
local function err(id)
	plex.err('Parser',id)
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
function _M.init(fin)
	plex.init(fin)
	print ('inited plex, but then do what...')
end
function _M.startParse()
	nextToken()		-- Pre-read a token
	if not parseProgram() then
		print('Your program is poisonous..')
	end
end

-----------------------------------------------------------------------------
-- Debug functions
-----------------------------------------------------------------------------
function _M.status()
	print("Parser Status:")
	--print("fin =\t"..tostring(fin))
	--print("FIN =\t"..tostring(FIN))
	--print("cur =\t"..tostring(cur))
	print()
end
function _M.test(fin)
	_M.init(fin)
	_M.startParse()
end

-----------------------------------------------------------------------------
return _M
