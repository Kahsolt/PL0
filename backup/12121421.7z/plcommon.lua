#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 Common Data & Structure
-- Name: plcommon
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.0
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Gloal common variables & functions
-----------------------------------------------------------------------------
-- Meta-Info
TokenType={
	BAD=0,									-- Unknown
	ID=100,									-- Identifier
	CONST=101, VAR=102,						-- Announcer
	NUM=111, STR=112,						-- Datatype - supports float and string
	BEGIN=201, END=202,						-- Reserved Words <Block Structure>
	PROCEDURE=211, CALL=212,
	IF=221,	THEN=222, ELSE=223,
	WHILE=231, DO=232, REPEAT=233, UNTIL=234,
	ASSIGN=301,								-- Linker
	PERIOD=311,	COMMA=312, SEMICOLON=313,	-- Separator
	LRDBR=321, RRDBR=322,					-- Combiner
	ADD=401, SUB=402, MUL=403, DIV=404,		-- Arithmetic Operator
	MOD=405, PWR=406,
	NOT=411, AND=412,  OR=413,	 			-- Logic Operator
	EQU=421, NEQ=422, ELT=423, EGT=424,		-- Comparation Operator
	LES=425, GRT=426,
	READ=501, WRITE=502,					-- Inner Function
	ODD=511,
}
PCode={
	HLT=100,	-- Stop
	INT=101,	-- Stacktop move up/down
	LIT=102,	-- Load const to stacktop
	LOD=103,	-- Load var to stacktop
	CAL=201,	-- Call address
	JMP=202,	-- Goto address
	JPC=203,	-- Goto address with condition
	STO=301,	-- Store stacktop to var
	OPR=401,	-- Do calculation
	RED=501,	-- Readin var
	WRT=502,	-- Writeout stacktop
}
ErrorID={
	['100']=[[Progam Logical Error]],
	['101']='Cannot open input file',
	['102']='Cannot open output file',
	['111']='Function parseProgram() went wrong',
	['112']='Function parseSubProgram() went wrong',
	['113']='Function parseDeclareConst() went wrong',
	['114']='Function parseDefineConst() went wrong',
	['115']='Function parseDeclareVar() went wrong',
	['116']='Function parseDeclareProcedure() went wrong',
	['117']='Function parseProcedureHead() went wrong',
	['118']='Function parseStatemant() went wrong',
	['119']='Function parseStatemantCompoud() went wrong',
	['120']='Function parseStatemantAssign() went wrong',
	['121']='Function parseStatemantIf() went wrong',
	['122']='Function parseStatemantWhile() went wrong',
	['123']='Function parseStatemantRepeat() went wrong',
	['124']='Function parseStatemantCall() went wrong',
	['125']='Function parseStatemantRead() went wrong',
	['126']='Function parseStatemantWrite() went wrong',
	['127']='Function parseCondition() went wrong',
	['128']='Function parseAddSubOperator() went wrong',
	['129']='Function parseMulDivOperator() went wrong',
	['130']='Function parseRelationOperator() went wrong',
	['131']='Function parseExpression() went wrong',
	['132']='Function parseTerm() went wrong',
	['133']='Function parseFactor() went wrong',
	['134']='Function parseIdentifier() went wrong',
	['135']='Function parseNumber() went wrong',

	['200']=[[Value Error]],
	['201']='Number too big',

	['300']=[[Structure Error]],
	['301']='Missing "."',
	['302']='Missing ")"',
	['303']='Missing "="',
	['304']='Missing "," or ";"',
	['305']='Missing an Identifier',
	['351']='Should be an Identifier',
	['352']='Should be a Const Definition',
	['372']='Should be "DO"',
	['373']='Should be "THEN"',
	['374']='Should be ";" or "END"',
	['375']='Should be ":="',
	['376']='Should be "CONST"',
	['377']='Should be a Statement',
	['378']='Should be "REPEAT"',
	['379']='Should be "UNTIL"',
	['380']='Should be "("',

	['400']=[[Operation Error]],
	['401']='Identifier not declared',
	['402']='Cannot assign a nen-VAR',
}
FileIn	 = ''		-- Input file
FileOut  = ''		-- Output file

--Status
Cur_Line  = 1		-- Cursor line of source file
Cur_Column = 0		-- Cursor column of source file
Cur_Count = 0		-- Cursor of destination file
Token = {}			-- Current token
SymbolTable = {}	-- Current symtab