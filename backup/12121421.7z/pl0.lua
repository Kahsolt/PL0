#!/usr/bin/lua5.3
require 'plarse'

if #arg ~= 2 then
	print('pl0.lua l|p <fpath>')
elseif arg[1] == 'l' then
	plex.test(arg[2])
elseif arg[1] == 'p' then
	plarse.test(arg[2])
end
