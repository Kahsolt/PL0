#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 P-Code Generator module
-- Name: plode
-- Author: Kahsolt
-- Time: 2016-12-18
-- Version: 1.5
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
plode = {}				-- 模块名
local _M = plode		-- 临时模块名
dofile('plenv.lua')		-- 执行全局参数设定
require 'plerr'

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
-- Tools
local function toPCode(pcmd)
	for k,v in pairs(PCode) do
		if v==pcmd then
			return tostring(k)
		end
	end
end
local function err(id)
	plerr.what('Plerr',id)
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
function _M.init(fout)
	FileOut = io.open(fout, "w")
	Address = PL0_Address
	Cur_Count = 0
	if not FileOut then
		err(102)
		return false
	end
	return true
end
function _M.fillAddress(index,address)
	if CodeSet[index] then
		CodeSet[index].x=address
		return true
	else
		return false
	end
end
function _M.count()
	return #CodeSet
end
function _M.write(pcmd,layerdiff,x)
	CodeSet[#CodeSet+1]={}
	CodeSet[#CodeSet].pcmd=toPCode(pcmd)		-- convert to 3 Letter OP
	CodeSet[#CodeSet].layerdiff=layerdiff
	CodeSet[#CodeSet].x=x
	Cur_Count=#CodeSet
end
function _M.output()
	for k,v in pairs(CodeSet) do
		FileOut:write(v.pcmd..' '..v.layerdiff..' '..v.x..'\n')
	end
end

-----------------------------------------------------------------------------
-- Debug functions
-----------------------------------------------------------------------------
function _M.status()
	print("PCoder Status:")
	print("Line\t=\t"..Cur_Line)
	print("Token\t=\t"..Token.type.."\t"..Token.value)
	print()
end
function _M.test()
	local cnt = 1
	for k,v in pairs(CodeSet) do
		print('['..cnt..']\t'..(v.pcmd or '<BAD>')..' '..(v.layerdiff or '<BAD>')..' '..(v.x or '<BAD>'))
		cnt=cnt+1
	end
end

-----------------------------------------------------------------------------
return _M
