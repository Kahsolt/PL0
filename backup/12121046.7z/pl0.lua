#!/usr/bin/lua5.3
require 'plex'

plex.test(arg[1])
