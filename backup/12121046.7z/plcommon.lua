#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 Common Data & Structure
-- Name: plcommon
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.0
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Gloal common variables & functions
-----------------------------------------------------------------------------
-- Meta-Info
TokenType={
	BAD=0,									-- Unknown
	ID=100,									-- Identifier
	CONST=101, VAR=102,						-- Announcer
	NUM=111, STR=112,						-- Datatype - supports float and string
	BEGIN=201, END=202,						-- Reserved Words <Block Structure>
	PROCEDURE=211, CALL=212,
	IF=221,	THEN=222, ELSE=223,
	WHILE=231, DO=232, REPEAT=233, UNTIL=234,
	ASSIGN=301,								-- Linker
	PERIOD=311,	COMMA=312, SEMICOLON=313,	-- Separator
	LRDBR=321, RRDBR=322,					-- Combiner
	ADD=401, SUB=402, MUL=403, DIV=404,		-- Arithmetic Operator
	MOD=405, PWR=406,
	NOT=411, AND=412,  OR=413,	 			-- Logic Operator
	EQU=421, NEQ=422, ELT=423, EGT=424,		-- Comparation Operator
	LES=425, GRT=426,
	READ=501, WRITE=502,					-- Inner Function
	ODD=511,
}
PCode={
	HLT=100,	-- Stop
	INT=101,	-- Stacktop move up/down
	LIT=102,	-- Load const to stacktop
	LOD=103,	-- Load var to stacktop
	CAL=201,	-- Call address
	JMP=202,	-- Goto address
	JPC=203,	-- Goto address with condition
	STO=301,	-- Store stacktop to var
	OPR=401,	-- Do calculation
	RED=501,	-- Readin var
	WRT=502,	-- Writeout stacktop
}
ErrorType={
	['000']=[[Progam Logical Error]],
	['001']='Cannot open input file',
	['002']='Cannot open output file',
	['011']='Function parseProgram() went wrong'
	['012']='Function parseSubProgram() went wrong'

	['100']=[[Value Error]],
	['101']='Number too big',

	['200']=[[Structure Error]],
	['201']='Missing "."',
	['202']='Missing ")"',
	['203']='Missing "="',
	['204']='Missing "," or ";"',
	['251']='Should be an Identifier',
	['252']='Should be "do"',
	['253']='Should be "then"',
	['254']='Should be ";" or "end"',
	['255']='Should be ":="',

	['300']=[[Operation Error]],
	['301']='Identifier not declared',
	['302']='Cannot assign a nen-VAR',
}
FileIn	 = ''		-- Input file
FileOut  = ''		-- Output file

--Status
Cur_Line  = 1		-- Cursor line of source file
Cur_Column = 0		-- Cursor column of source file
Cur_Count = 0		-- Cursor of destination file
Token = {}			-- Current token
SymbolTable = {}	-- Current symtab