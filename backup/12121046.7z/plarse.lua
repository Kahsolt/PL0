#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 Parser module
-- Name: plarse
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.1
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
plarse = {}			-- 模块名
local _M = plarse	-- 临时模块名
require 'plcommon'	-- 引入模块
require 'plex'
require 'plerr'

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
local layer = 0
local address = 0

-- Parsers
local function parseProgram()			-- ﻿<程序> ::= <分程序>.
	parseSubProgram()
	if Token.type == TokenType.PERIOD then
		return true
	else
		err(201)
		return false
	end
	err(011)
end
local function parseSubProgram()		-- <分程序> ::= [<常量说明部分>][变量说明部分>][<过程说明部分>]<语句>
	if Token.type==TokenType.CONST then
		return parseDeclareConst()  end
	elseif Token.type==TokenType.VAR then
		return parseDeclareVar() end
	elseif Token.type==TokenType.PROCEDURE then
		return parseDeclareProcedure() end
	else
		return parseStatemant() end
	end
	err(012)
end
local function parseDeclareConst()		-- <常量说明部分> ::= const<常量定义>{,<常量定义>};
	if Token.type==TokenType.CONST then
		plex.nextToken()
		if parseDefineConst() then
			while true do
				if Token.type==TokenType.COMMA then
					plex.nextToken()
					parseDefineConst()
				else
					err(2,'Missing CONST DECLARATION after this Comma')
					return false
				end
			end
		else
			return false
		end
		if Token.type==TokenType.SEMICOLON then
			return true
		else
			err(2,'Missing ending semicolon')
			return false
		end
	else
		err(-1,'Should not...Mising CONST?')
		return false
	end
end
local function parseDefineConst()		-- <常量定义> ::= <标识符>=<无符号整数>
	if Token.type==TokenType.ID then
		-- TODO: deal with id
		-- parseIdentifier()
		plex.nextToken()
		if Token.type==TokenType.EQU then
			plex.nextToken()
			-- TODO: deal with num
			-- parseNumber()
		else
			err(1,'Should be "=" here')
			return false
		end
	else
		err(-1,'Should not...Mising ID?')
		return false
	end
end
local function parseDeclareVar()		-- <变量说明部分>::= var<标识符>{,<标识符>};
	if Token.type==TokenType.VAR then
		plex.nextToken()
		-- TODO: deal with id
		-- parseIdentifier()
		while true do
			if Token.type==TokenType.COMMA then
				plex.nextToken()
				-- TODO: deal with id
				-- parseIdentifier()
			else
				break
			end
		end
		if Token.type==TokenType.SEMICOLON then
			return true
		else
			err(2,'Missing ending semicolon')
			return false
		end
	else
		err(-1,'Should not...Mising VAR?')
		return false
	end
end
local function parseDeclareProcedure()	-- <过程说明部分> ::= <过程首部><分程序>{;<过程说明部分>};
	if parseProcedureHead() then
		if parseSubProgram() then
			while true do
				if Token.type==TokenType.SEMICOLON then 	-- OBSTACLE: what if a null statement?
					if parseDeclareProcedure() then
						doNothing()
					else
						err(2,'Missing ending DeclareProcedure')
					end
				else
					break
				end
			end
		else
			panic(4,'Bad SubProgram')
			return false
		end
		if Token.type==TokenType.SEMICOLON then
			return true
		else
			err(2,'Missing ending semicolon')
			return false
		end
	else
		err(-1,'Should not...Mising PROCEDURE?')
		return false
	end
end
local function parseProcedureHead()		-- <过程首部> ::= procedure<标识符>;
	absorb(TokenType.PROCEDURE)
	parseIdentifier()
	absorb(TokenType.SEMICOLON)
end
local function parseStatemant()			-- <语句> ::= <赋值语句>|<条件语句>|<当型循环语句>|<过程调用语句>|<读语句>|<写语句>|<复合语句>|<重复语句>|<空>
	parseStatemantAssign()
	parseStatemantIf()
	parseStatemantWhile()
	parseStatemantRepeat()
	parseStatemantCall()
	parseStatemantRead()
	parseStatemantWrite()
	parseStatemantCompoud()
	parseStatemantNull()
end
local function parseStatemantCompoud()	-- <复合语句> ::= begin<语句>{;<语句>}end
	absorb(TokenType.BEGIN)
	parseStatemant()
	while absorb(TokenType.SEMICOLON) do
		parseStatemant()
	end
	absorb(TokenType.END)
end
local function parseStatemantAssign()	-- <赋值语句> ::= <标识符>:=<表达式>
	parseStatemant()
	absorb(TokenType.ASSIGN)
	parseExpression()
end
local function parseStatemantIf()		-- <条件语句> ::= if<条件>then<语句>[else<语句>]
	absorb(TokenType.IF)
	parseCondition()
	absorb(TokenType.THEN)
	parseStatemant()
	if absorb(TokenType.ELSE) do
		parseStatemant()
	end	
end
local function parseStatemantWhile()	-- <当型循环语句> ::= while<条件>do<语句>
	absorb(TokenType.WHILE)
	parseCondition()
	absorb(TokenType.DO)
	parseStatemant()
end
local function parseStatemantRepeat()	-- <重复语句> ::= repeat<语句>{;<语句>}until<条件>
	absorb(TokenType.REPEAT)
	parseStatemant()
	while absorb(TokenType.SEMICOLON) do
		parseStatemant()
	end
	absorb(TokenType.UNTIL)
	parseCondition()
end
local function parseStatemantCall()		-- <过程调用语句> ::= call<标识符>
	absorb(TokenType.CALL)
	parseIdentifier()
end
local function parseStatemantRead()		-- <读语句> ::= read'('<标识符>{,<标识符>}')‘
	absorb(TokenType.READ)
	absorb(TokenType.LRDBR)
	parseIdentifier()
	while absorb(TokenType.COMMA) do
		parseIdentifier()
	end
	absorb(TokenType.RRDBR)
end
local function parseStatemantWrite()	-- <写语句> ::= write'('<标识符>{,<标识符>}')‘
	absorb(TokenType.READ)
	absorb(TokenType.LRDBR)
	parseIdentifier()
	while absorb(TokenType.COMMA) do
		parseIdentifier()
	end
	absorb(TokenType.RRDBR)
end
local function parseCondition()			-- <条件> ::= <表达式><关系运算符><表达式>|odd<表达式>
	parseExpression()
	parseRelationOperator()
	parseExpression()

	absorb(TokenType.ODD)
	parseExpression()
end
local function parseAddSubOperator()	-- <加法运算符> ::= +|-
	absorb(TokenType.ADD)
	absorb(TokenType.SUB)
end
local function parseMulDivOperator()	-- <乘法运算符> ::= *|/
	absorb(TokenType.MUL)
	absorb(TokenType.DIV)
end
local function parseRelationOperator()	-- <关系运算符> ::= =|<>|<|<=|>|>=
	absorb(TokenType.EQU)
	absorb(TokenType.NEQ)
	absorb(TokenType.LES)
	absorb(TokenType.ELT)
	absorb(TokenType.GRT)
	absorb(TokenType.EGT)
end
local function parseExpression()		-- <表达式> ::= [+|-]<项>{<加法运算符><项>}
	absorb(TokenType.ADD)
	absorb(TokenType.SUB)
	parseTerm()
	while parseAddSubOperator() do
		parseTerm()
	end
end
local function parseTerm()				-- <项> ::= <因子>{<乘法运算符><因子>}
	parseFactor()
	while parseMulDivOperator() do
		parseFactor()
	end
end
local function parseFactor()			-- <因子> ::= <标识符>|<无符号整数>|'('<表达式>')‘
	parseIdentifier()
	parseNumber()
	absorb(TokenType.LRDBR)
	parseExpression()
	absorb(TokenType.RRDBR)
end
local function parseIdentifier()		-- <标识符> ::= <字母>{<字母>|<数字>}
	absorb(TokenType.ID)
end
local function parseNumber()			-- <无符号整数> ::= <数字>{<数字>}
	absorb(TokenType.NUM)
end

-- Tools
local function err(id,msg)
	if id == 0 then			-- Fatal Error
		print('<<Parser Fatal Error>>: '..msg)
		os.exit()
	else
		print('[Parsing Error]: #'..Cur_Line..':'..Cur_Column..' => '..msg)
	end
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
function _M.init(fin)
	plex.init(fin)
	print ('inited plex, but then do what...')
end
function _M.startParse()
	plex.nextToken()	-- Pre-read a token
	if not parseProgram() then
		err(0,'Cannot parse...')
	end
end

-----------------------------------------------------------------------------
-- Debug functions
-----------------------------------------------------------------------------
function _M.status()
	print("Parser Status:")
	--print("fin =\t"..tostring(fin))
	--print("FIN =\t"..tostring(FIN))
	--print("cur =\t"..tostring(cur))
	print()
end
function _M.test(fin)
	_M.init(fin)
	print('How to test...')
end

-----------------------------------------------------------------------------
return _M
