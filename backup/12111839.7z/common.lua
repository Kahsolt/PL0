#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 Common Data & Structure
-- Name: common
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.0
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Public common variables & functions
-----------------------------------------------------------------------------
TokenType={
	BAD=0,									-- Unknown
	ID=100,									-- Identifier
	CONST=101, VAR=102,						-- Announcer
	NUM=111, STR=112,						-- Datatype - supports float and string
	BEGIN=201, END=202,						-- Block Structure
	PROCEDURE=211, CALL=212,
	IF=221, THEN=222, ELSE=223,
	WHILE=231, DO=232, REPEAT=233, UNTIL=234,
	ASSIGN=301,								-- Linker
	PERIOD=311, COMMA=312, SEMICOLON=313,	-- Separator
	LRDBR=321, RRDBR=322,					-- Combiner
	ADD=401, SUB=402, MUL=403, DIV=404,		-- Arithmetic Operator
	MOD=405, PWR=406,
	NOT=411, AND=412, OR=413,	 			-- Logic Operator
	EQU=421, NEQ=422, ELT=423, EGT=424,		-- Comparation Operator
	LESMissing？？en：：=425, GRT=426,
	READ=501, WRITE=502,					-- Inner Function
	ODD=511
}
fin=nil		-- Source file
cur=0		-- Current line
token={}	-- the to-return TOKEN with: name, val