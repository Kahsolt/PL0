#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 Lexer module
-- Name: plex
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.3
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
plex = {}			-- 模块名
local _M = plex		-- 临时模块名
loadfile('common.lua')

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
local FIN=false		-- Whether is done
local input=''		-- Current char
local inputs=''		-- Current buffer

-- Judger
local function isEOF()		return not input	end
local function isNL()		return input=='\n'	end
local function isNonsense()	return input=='\0' or input==' ' or input=='' or input=='\t' or input=='\r' or input=='\n' end
local function isLetter()	return input and ('A'<=input and input<='Z' or 'a'<=input and input<='z') end
local function isDigit()	return input and ('0'<=input and input<='9') end
local function isAdd()		return input=='+'	end
local function isSub()		return input=='-'	end
local function isMul()		return input=='*'	end
local function isDiv()		return input=='/'	end
local function isMod()		return input=='%'	end
local function isPwr()		return input=='^'	end
local function isEqu()		return input=='='	end
local function isLes()		return input=='<'	end
local function isGrt()		return input=='>'	end
local function isPeriod()	return input=='.'	end
local function isComma()	return input==','	end
local function isSemiColon()return input==';'	end
local function isColon()	return input==':'	end
local function isQuote()	return input=="'"	end
local function isLrdbr()	return input=='('	end
local function isRrdbr()	return input==')'	end
local function isLagbr()	return input=='<'	end
local function isRagbr()	return input=='>'	end
local function isLclbr()	return input=='{'	end
local function isRclbr()	return input=='}'	end
local isStar	= isMul
-- Operation
local function chkReserved()return TokenType[string.upper(inputs)] end
local function calcValue()
	return tonumber(inputs)
end
local function readInput()
	input=fin:read(1)
	if not input then
		FIN=true
		-- print("<Got EOF!!>")
	end
	if input=='\n' then cur=cur+1 end		-- compatible with Windows & Linux
	return input
end
local function unreadInput()
	fin:seek("cur",-1)
end
local function resetInputs()
	input = ''
	inputs = ''
	token = {}
end
local function catInputs()
	inputs = inputs..input
end
local function err(id,msg)
	if id == 0 then	-- Fatal Error
		print('<<Lexer Fatal Error>>: '..msg)
		os.exit()
	else
		print('[Lexing Error]: Line #'..cur..' => '..msg)
	end
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
function _M.init(fpath)
	fin = io.open(fpath, "r")
	FIN = false
	cur = 0
	if not fin then
		err(0,"File cannot open")
		return false
	end
	return true
end
function _M.nextToken()
	resetInputs()
	while not FIN and isNonsense() do readInput() end
	if FIN then return nil end

	-- print('[Get Char:] <'..input..'>')		-- caught one meaningful char
			
	if isLetter() then
		while isLetter() or isDigit() do
			catInputs()
			readInput()
		end
		unreadInput()
		token['type'] = chkReserved() or TokenType.ID
		token['val'] = inputs
	elseif isDigit() then
		local _dot = 0
		while isDigit() or isPeriod() do
			if isPeriod() then
				_dot=_dot+1
				if _dot >= 2 then
				err(2,"Bad float number")
				end
			end
			catInputs()
			readInput()
		end
		unreadInput()
		token['type']=TokenType.NUM
		token['val']=calcValue()
	elseif isQuote() then
		while not isNL() do
			catInputs()
			readInput()
			if isQuote() then
				catInputs()
				token['type']=TokenType.STR
				token['val']=inputs
				break
			end
		end
		if isNL() then
			err(1,"String missing right quote \'")
		end
	elseif isAdd()		then token['type']=TokenType.ADD			-- '+'
	elseif isSub()		then token['type']=TokenType.SUB			-- '-'
	elseif isMul()		then token['type']=TokenType.MUL			-- '*'
	elseif isDiv() 		then token['type']=TokenType.DIV			-- '/'
	elseif isMod() 		then token['type']=TokenType.MOD			-- '%'	
	elseif isPwr() 		then token['type']=TokenType.PWR			-- '^'
	elseif isEqu()		then token['type']=TokenType.EQU			-- '='
	elseif isLrdbr()	then token['type']=TokenType.LRDBR			-- '('
	elseif isRrdbr()	then token['type']=TokenType.RRDBR			-- ')'
	elseif isPeriod()	then token['type']=TokenType.PERIOD			-- '.'
	elseif isComma()	then token['type']=TokenType.COMMA			-- ','
	elseif isSemiColon()then token['type']=TokenType.SEMICOLON		-- ';'
	elseif isColon() then
		readInput()
		if isEqu() then token['type']=TokenType.ASSIGN			-- ':='
		else
			unreadInput()
			err(1,"Single ':', missing '=' ?")
		end
	elseif isLagbr() then
		readInput()
		if isEqu() then
			token['type']=TokenType.ELT		-- '<='
		elseif isRagbr() then
			token['type']=TokenType.NEQ		-- '<>'
		else
			token['type']=TokenType.LES		-- '<'
			unreadInput()
		end
	elseif isRagbr() then
		readInput()
		if isEqu() then
			token['type']=TokenType.EGT		-- '>='
		else
			token['type']=TokenType.GRT		-- '>'
			unreadInput()
		end
	elseif isLclbr() then
		readInput()
		if isStar() then					-- '{*' skip multiline comments
			repeat
				repeat readInput() until isStar() or isEOF()
				repeat readInput()
					if isRclbr() then return nextToken() end
				until isStar() or isEOF()
			until not isStar() or isEOF()
		else 								-- '{' skip inline comment
			repeat readInput() until isRclbr() or isNL() or isEOF()
			if isRclbr() then return nextToken()
			else err(1,"Missing character '}'") end
		end	
	else err(1,"Unkown character.") end

	return token
end
function _M.lastToken()
	return lastToken
end
-----------------------------------------------------------------------------
-- Debug Functions
-----------------------------------------------------------------------------
function _M.status()
	print("Lexer Status:")
	-- print("fin\t=\t"..tostring(fin))
	print("FIN\t=\t"..tostring(FIN))
	print("cur\t=\t"..tostring(cur))
	print("token\t=\t"..tostring(token['type']).."\t"..tostring(token['val']))
	print()
end
function _M.test(fpath)
	_M.init(fpath)
	_M.status()
	print("<Type>\t<Value>")
	while true do
		t=_M.nextToken()
		if not t then break end
		print(t['type'] or '',t['val'] or '')
	end
end

-----------------------------------------------------------------------------
return _M
