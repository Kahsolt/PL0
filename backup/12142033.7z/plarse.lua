#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 Parser module
-- Name: plarse
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.1
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
plarse = {}			-- 模块名
local _M = plarse	-- 临时模块名
dofile('plenv.lua')	-- 引入模块
require 'plex'
require 'plerr'

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
local layer = 0
local address = 0
local 	parseProgram, parseSubProgram, parseDeclareConst, parseDefineConst, parseDeclareVar, parseDeclareProcedure, parseProcedureHead, 
		parseStatemant, parseStatemantCompoud, parseStatemantAssign, parseStatemantIf, parseStatemantWhile, parseStatemantRepeat, parseStatemantCall, parseStatemantRead, parseStatemantWrite, 
		parseCondition, parseAddSubOperator, parseMulDivOperator, parseExpression, parseTerm, parseFactor, parseIdentifier, parseNumber, parseString

-- Tools
local function testToken(type)		-- test only
	return Token.type==TokenType[type]
end
local function absorbToken(type)	-- test, if match then get next token
	if Token.type==TokenType[type] then
		plex.nextToken()
		return true
	else
		return false
	end
end
local function err(id)
	plerr.what('Plarse',id)
end

-- Local Debug
local function dbg(func)
	print('[Func] '..func..'\t\t[Token] '..(Token.type or '<NK>')..'\t'..(Token.val or '<Symbol>'))
end

-- Parsers
function parseProgram()			-- ﻿<程序> ::= <分程序>.
	dbg('Program')
	parseSubProgram()	-- unsure
	if absorbToken('PERIOD') then
		return true
	else
		err(301)
		return false
	end
end
function parseSubProgram()		-- <分程序> ::= [<常量说明部分>][变量说明部分>][<过程说明部分>]<语句>
	dbg('SubProgram')
	while testToken('CONST') or testToken('VAR') or testToken('PROCEDURE') do
		if testToken('CONST') then parseDeclareConst()	end
		if testToken('VAR') then parseDeclareVar()	end
		if testToken('PROCEDURE') then parseDeclareProcedure() end
	end
	parseStatemant()	-- unsure
end
function parseDeclareConst()		-- <常量说明部分> ::= const<常量定义>{,<常量定义>};
	dbg('DeclareConst')
	if absorbToken('CONST') then
		parseDefineConst()
		while absorbToken('COMMA') do
			parseDefineConst()
		end
		if absorbToken('SEMICOLON') then
			return true
		else
			err(302)
			return false
		end
	else
		return false
	end
end
function parseDefineConst()		-- <常量定义> ::= <标识符>=<无符号整数>
	dbg('DefineConst')
	if testToken('ID') then
		parseIdentifier()
		-- TODO: deal with id
		if absorbToken('EQU') then
			parseNumber()
			-- TODO: deal with num
			return true
		else
			err(303)
			return false
		end
	else
		return false
	end
end
function parseDeclareVar()		-- <变量说明部分>::= var<标识符>{,<标识符>};
	dbg('DeclareVar')
	if absorbToken('VAR') then
		parseIdentifier()
		-- TODO: deal with id
		while absorbToken('COMMA') do
			parseIdentifier()
		end
		if absorbToken('SEMICOLON') then
			return true
		else
			err(302)
			return false
		end
	else
		return false
	end
end
function parseDeclareProcedure()	-- <过程说明部分> ::= <过程首部><分程序>;{<过程说明部分>} -- Modified
	dbg('DeclareProcedure')
	parseProcedureHead()
	parseSubProgram()
	if absorbToken('SEMICOLON') then
		return true
	else
		err(302)
		return false
	end
	while absorbToken('PROCEDURE') do
		parseDeclareProcedure()
	end
end
function parseProcedureHead()		-- <过程首部> ::= procedure<标识符>;
	dbg('ProcedureHead')
	if absorbToken('PROCEDURE') then
		parseIdentifier()
		if absorbToken('SEMICOLON') then
			return true
		else
			err(302)
			return false
		end
	else
		return false
	end
end
function parseStatemant()			-- <语句> ::= <赋值语句>|<条件语句>|<当型循环语句>|<过程调用语句>|<读语句>|<写语句>|<复合语句>|<重复语句>|<空>
	dbg('Statemant')
	if testToken('BEGIN') then return parseStatemantCompoud()
	elseif testToken('ID') then return parseStatemantAssign()
	elseif testToken('IF') then return parseStatemantIf()
	elseif testToken('WHILE') then return parseStatemantWhile()
	elseif testToken('DO') then return parseStatemantWhile()
	elseif testToken('REPEAT') then return parseStatemantRepeat()
	elseif testToken('CALL') then return parseStatemantCall()
	elseif testToken('READ') then return parseStatemantRead()
	elseif testToken('WRITE') then return parseStatemantWrite()
	elseif absorbToken('SEMICOLON') then return true		-- Null Statement
	else return false end
end
function parseStatemantCompoud()	-- <复合语句> ::= begin<语句>{;<语句>}end
	dbg('StatemantCompoud')
	if absorbToken('BEGIN') then
		if absorbToken('END') then return true end	-- Support Nil Statement
		parseStatemant()
		while absorbToken('SEMICOLON') do
			parseStatemant()
		end
		if absorbToken('END') then
			return true
		else
			err(304)
			return false
		end
	else
		return false
	end
end
function parseStatemantAssign()	-- <赋值语句> ::= <标识符>:=<表达式>
	dbg('StatemantAssign')
	parseIdentifier()
	if absorbToken('ASSIGN') then
		parseExpression()
		return true
	else
		err(305)
		return false
	end
end
function parseStatemantIf()		-- <条件语句> ::= if<条件>then<语句>[else<语句>]
	dbg('StatemantIf')
	if absorbToken('IF') then
		parseCondition()
		if absorbToken('THEN') then
			parseStatemant()
			if absorbToken('ELSE') then
				parseStatemant()
				return true
			end
			return true
		else
			err(306)
			return false
		end
	else
		return false
	end
end
function parseStatemantWhile()	-- <当型循环语句> ::= while<条件>do<语句>|do<语句>while<条件>
	dbg('StatemantWhile')
	if absorbToken('WHILE') then
		parseCondition()
		if absorbToken('DO') then
			parseStatemant()
			return true
		else
			err(307)
			return false
		end
	elseif absorbToken('DO') then
		parseStatemant()
		if absorbToken('WHILE') then
			parseCondition()
			return true
		else
			err(308)
			return false
		end
	else
		return false
	end
end
function parseStatemantRepeat()	-- <重复语句> ::= repeat<语句>{;<语句>}until<条件>
	dbg('StatemantRepeat')
	if absorbToken('REPEAT') then
		parseStatemant()
		while absorbToken('SEMICOLON') do
			parseStatemant()
		end
		if absorbToken('UNTIL') then
			parseCondition()
			return true
		else
			err(309)
			return false
		end
	else
		return false
	end
end
function parseStatemantCall()		-- <过程调用语句> ::= call<标识符>
	dbg('StatemantCall')
	if absorbToken('CALL') then
		parseIdentifier()
		return true
	else
		return false
	end
end
function parseStatemantRead()		-- <读语句> ::= read'('<标识符>{,<标识符>}')‘
	dbg('StatemantRead')
	if absorbToken('READ') then
		if absorbToken('LRDBR') then
			parseIdentifier()
			while absorbToken('COMMA') do
				parseIdentifier()
			end
			if absorbToken('RRDBR') then
				return true
			else
				err(311)
				return false
			end
		else
			err(310)
			return false
		end
	else
		return false
	end
end
function parseStatemantWrite()	-- <写语句> ::= write'('<标识符>{,<标识符>}')‘
	dbg('StatemantWrite')
	if absorbToken('WRITE') then
		if absorbToken('LRDBR') then
			parseIdentifier()
			while absorbToken('COMMA') do
				parseIdentifier()
			end
			if absorbToken('RRDBR') then
				return true
			else
				err(311)
				return false
			end
		else
			err(310)
			return false
		end
	else
		return false
	end
end
function parseCondition()			-- <条件> ::= <表达式><关系运算符><表达式>|odd<表达式>
	dbg('Condition')
	if absorbToken('ODD') then
		parseExpression()
		return true
	else
		parseExpression()
		parseRelationOperator()
		parseExpression()
		return true
	end
end
function parseAddSubOperator()	-- <加法运算符> ::= +|-
	dbg('AddSubOperator')
	if absorbToken('ADD') then
		return true
	elseif absorbToken('SUB') then
		return true
	else
		return false
	end
end
function parseMulDivOperator()	-- <乘法运算符> ::= *|/|%
	dbg('MulDivOperator')
	if absorbToken('MUL') then
		return true
	elseif absorbToken('DIV') then
		return true
	elseif absorbToken('MOD') then
		return true
	else
		return false
	end
end
function parseRelationOperator()	-- <关系运算符> ::= =|<>|<|<=|>|>=
	dbg('RelationOperator')
	if absorbToken('EQU') then
		return true
	elseif absorbToken('NEQ') then
		return true
	elseif absorbToken('LES') then
		return true
	elseif absorbToken('ELT') then
		return true
	elseif absorbToken('GRT') then
		return true
	elseif absorbToken('EGT') then
		return true
	else
		return false
	end
end
function parseExpression()		-- <表达式> ::= [+|-]<项>{<加法运算符><项>}
	dbg('Expression')
	local _sign = 0		-- pos=0,neg=1
	if absorbToken('ADD') then
		_sign=0
	elseif absorbToken('SUB') then
		_sign=1
	end
	parseTerm()
	while parseAddSubOperator() do
		parseTerm()
	end
	return true
end
function parseTerm()				-- <项> ::= <因子>{<乘法运算符><因子>}
	dbg('Term')
	parseFactor()
	while parseMulDivOperator() do
		parseFactor()
	end
	return true
end
function parseFactor()			-- <因子> ::= <标识符>|<数>|'('<表达式>')‘
	dbg('Factor')
	if testToken('ID') then
		return parseIdentifier()
	elseif testToken('NUM') then
		return parseNumber()
	elseif absorbToken('LRDBR') then
		parseExpression()
		if absorbToken('RRDBR') then
			return true
		else
			err(311)
			return false
		end
	else
		return false
	end
end
function parseIdentifier()		-- <标识符> ::= <字母>{<字母>|{<数字>}}
	dbg('Identifier')
	if testToken('ID') then
		plex.nextToken()	-- absorb for debug
		-- TODO: save to symtab
		return true
	else
		return false
	end
end
function parseNumber()			-- <数> ::= <数字>{<数字>}.{<数字>}
	dbg('Number')
	if testToken('NUM') then
		plex.nextToken()	-- absorb for debug
		-- TODO returnval?
		return true
	else
		return false
	end
end
function parseString()			-- <字符串> ::= <支持字符>{<支持字符>}	-- single quotes has been took off
	dbg('String')
	if testToken('STR') then
		plex.nextToken()	-- absorb for debug
		-- TODO returnval?
		return true
	else
		return false
	end
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
function _M.init(fin)
	plex.init(fin)
end
function _M.startParse()
	plex.nextToken()		-- Pre-read a token
	if not parseProgram() then
		print('#233: Your program is poisonous..')
	else
		print('#666: Parsing finished, no big problem currently...')
	end
end

-----------------------------------------------------------------------------
-- Debug functions
-----------------------------------------------------------------------------
function _M.test(fin)
	_M.init(fin)
	_M.startParse()
end

-----------------------------------------------------------------------------
return _M
