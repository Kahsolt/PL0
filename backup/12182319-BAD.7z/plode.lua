#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 P-Code Generator module
-- Name: plode
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.0
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Declare module & import dependencies
-----------------------------------------------------------------------------
plode = {}				-- 模块名
local _M = plode		-- 临时模块名
dofile('plenv.lua')		-- 执行全局参数设定
require 'plerr'

-----------------------------------------------------------------------------
-- Private variables & functions
-----------------------------------------------------------------------------
-- Tools
local function toPCode(pcmd)
	for k,v in pairs(PCode) do
		if v==pcmd then
			return tostring(k)
		end
	end
end
local function err(id)
	plerr.what('Plerr',id)
end

-----------------------------------------------------------------------------
-- Pulic variables & functions
-----------------------------------------------------------------------------
function _M.init(fout)
	FileOut = io.open(fout, "w")
	Layer = 0
	Address = 10
	Cur_Count = 0
	if not FileOut then
		err(102)
		return false
	end
	return true
end
function _M.write(pcmd,layerdiff,x)
	Cur_Count=Cur_Count+1
	CodeSet[Cur_Count]={}
	CodeSet[Cur_Count].pcmd=toPCode(pcmd)		-- convert to 3 Letter OP
	CodeSet[Cur_Count].layerdiff=layerdiff
	CodeSet[Cur_Count].x=x
end
function _M.output()
	for k,v in pairs(CodeSet) do
		FileOut:write(v.pcmd..' '..v.layerdiff..' '..v.x..'\n')
	end
end

-----------------------------------------------------------------------------
-- Debug functions
-----------------------------------------------------------------------------
function _M.status()
	print("PCoder Status:")
	print("Line\t=\t"..Cur_Line)
	print("Token\t=\t"..Token.type.."\t"..Token.value)
	print()
end
function _M.test(fout)
	_M.init(fout)
	_M.write(PCode.WRT,0,0)
end

-----------------------------------------------------------------------------
return _M
