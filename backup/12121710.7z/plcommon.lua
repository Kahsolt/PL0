#!/usr/bin/lua5.3
-----------------------------------------------------------------------------
-- PL/0 Common Data & Structure
-- Name: plcommon
-- Author: Kahsolt
-- Time: 2016-12-10
-- Version: 1.0
-- Lua Ver: 5.3
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-- Gloal common variables & functions
-----------------------------------------------------------------------------
-- Meta-Info
TokenType={
	BAD=0,									-- Unknown Char
	ID=100,									-- Identifier
	CONST=101, VAR=102,						-- Announcer
	NUM=111, STR=112,						-- Datatype - supports float and string
	BEGIN=201, END=202,						-- Reserved Words <Block Structure>
	PROCEDURE=211, CALL=212,
	IF=221,	THEN=222, ELSE=223,
	WHILE=231, DO=232, REPEAT=233, UNTIL=234,
	ASSIGN=301,								-- Linker
	PERIOD=311,	COMMA=312, SEMICOLON=313,	-- Separator
	LRDBR=321, RRDBR=322,					-- Combiner
	ADD=401, SUB=402, MUL=403, DIV=404,		-- Arithmetic Operator
	MOD=405, PWR=406,
	NOT=411, AND=412,  OR=413,	 			-- Logic Operator
	EQU=421, NEQ=422, ELT=423, EGT=424,		-- Comparation Operator
	LES=425, GRT=426,
	READ=501, WRITE=502,					-- Inner Function
	ODD=511,
}
PCode={
	HLT=100,	-- Stop
	INT=101,	-- Stacktop move up/down
	LIT=102,	-- Load const to stacktop
	LOD=103,	-- Load var to stacktop
	CAL=201,	-- Call address
	JMP=202,	-- Goto address
	JPC=203,	-- Goto address with condition
	STO=301,	-- Store stacktop to var
	OPR=401,	-- Do calculation
	RED=501,	-- Readin var
	WRT=502,	-- Writeout stacktop
}
ErrorMessage={
	-- [[Fatal Logical Error]] --
	['100']='Mystical Error..',
	['101']='Cannot open input file',
	['102']='Cannot open output file',
	-- [[Lexing Error]] --
	['200']='Unkown character',
	['201']='Number too big',
	['202']='Bad float number',
	['203']='String missing right quote \'\'\'',
	['211']='Assignment missing equal \'=\'',
	['291']='Comment missing character right curl bracket\'}\'',
	-- [[Parsing Error]] --
	['300']='Bad Sentence Structure',
	['301']='Missing "."',
	['302']='Missing ")"',
	['303']='Should be ":="',
	['304']='Missing "," or ";"',
	['305']='Missing an Identifier',
	['351']='Should be an Identifier',
	['352']='Should be a Const Definition',
	['372']='Should be "DO"',
	['373']='Should be "THEN"',
	['374']='Should be ";" or "END"',
	['375']='Should be ":="',
	['376']='Should be "CONST"',
	['377']='Should be a Statement',
	['378']='Should be "REPEAT"',
	['379']='Should be "UNTIL"',
	['380']='Should be "("',
	['391']='Identifier not declared',
	['392']='Cannot assign a nen-VAR',
}
FileIn	 = ''		-- Input file
FileOut  = ''		-- Output file

--Status
Cur_Line  = 1		-- Cursor line of source file
Cur_Column = 0		-- Cursor column of source file
Cur_Count = 0		-- Cursor of destination file
Token = {}			-- Current token
SymbolTable = {}	-- Current symtab